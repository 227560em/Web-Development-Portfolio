// 1. create an array of words to be guessed
let cuisines = ["Italian", "Chinese", "Japanese", "Greek", "French", "Korean", "Australian", "Indian"];

// 2. Create the initial game settings
var answer = "";
// storage of the list of letters the player has guessed
var guessed = [];
var wordprogress = null;

// 3. creat a function to randomize the word to be guessed
function randomword() {
  // calling the list, making sure that the number of items in the list is an integer grabbing a random item from that list based on the list
  answer = cuisines[Math.floor(Math.random() * cuisines.length)]
}

// 4. create a function to generate the keyboard buttons
function keyboard() {
  let buttonsinHTML = "abcdefghijklmnopqrstwxyz".split("").map(letter => `<button class=" btn btn-lg btn-info m-2" id='` + letter + `' Onclick="guess('` + letter + `')">` + letter + `</button>`).join("");
  document.getElementById("keyboard").innerHTML = buttonsinHTML;
}

keyboard();